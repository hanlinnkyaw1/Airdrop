// config.js
const config = {
  blumLink: 'https://t.me/blum/app?startapp=ref_tdTUyIIgc9',
  hamsterLink: 'https://t.me/haMster_kombat_bot/start?startapp=kentId5126901642'
};

export default config;